# comana

Passo a passo para fazer rodar

vá até seu venv, para instalar os packages necessarios:

pip install -r requirements.txt


Para rodar a plataforma

streamlit run app.py
